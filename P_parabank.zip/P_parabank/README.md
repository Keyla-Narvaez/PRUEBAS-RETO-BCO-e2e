# Automatización de pruebas Cypress E2E - Reto técnico ParaBank "una experiencia diferente"

Este proyecto contiene una suite de pruebas automatizadas E2E desarrolladas en Cypress JS, con soporte para Cucumber (Gherkin) y patrón "Page Object Model" (POM). Las pruebas automatizan flujos clave del portal bancario: [https://parabank.parasoft.com/parabank/index.htm]

# Alcance de Funcionalidades:

- Registro de usuario.
- Inicio de sesión.
- Retiro de dinero.
- Transferencia entre cuentas.

# Caso de pruebas lenguaje Gherkin:

# 1.-Registro de Usuario

- Feature: Registro de nuevo usuario  
- Scenario: Usuario llena los campos correspondientes y se registra exitosamente con datos válidos.  
- Validación: mensaje de éxito + sesión activa automáticamente.

# 2.-Login

- Feature: Loguearse en el sistema  
- Scenario: Usuario se loguea con credenciales válidas.  
- Validación: acceso al resumen de cuentas con bienvenida.

# 3.-Retiro de Fondos

- Feature: Realizar un retiro  
- Scenario: Usuario retira fondos exitosamente desde una cuenta activa.  
- Validación: respuesta HTTP 200 y mensaje de confirmación.

# 4.-Transferencia Entre Cuentas

- Feature: Transferir fondos  
- Scenario: Transferencia de dinero entre dos cuentas válidas.  
- Validación: mensaje de "Transfer Complete" y cuentas involucradas actualizadas.

# Pasos de ejecución, el flujo de prueba está definido en prueba_parabank.spec.js y sigue esta secuencia:

- cy.register(); // Registro de nuevo usuario
- cy.logout(); // Cierre de sesión obligatorio para validar login
- cy.login('keylita123', 'Pass10!'); // Login exitoso
- cy.withdraw(25776, 20); // Retiro por API con validación
- cy.transfer('2', '25110', '25776'); // Transferencia entre cuentas

# Consideraciones Importantesr:
- Ambiente de Pruebas Volátil: Las cuentas y usuarios expiran al cabo de un tiempo. Si no puedes loguearte, probablemente necesites volver a registrarte.

- Usuarios Dinámicos:Si deseas usar usuarios únicos en cada ejecución, puedes modificar la función register() para concatenar un número incremental o timestamp al username.

- Datos de Cuenta: Los IDs de cuenta (25110, 25776) deben estar activos y con fondos suficientes para las operaciones de retiro y transferencia. Si fallan, revisa la creación de cuentas y verifica saldos manualmente desde la interfaz.

- Retiro por API: Se realiza mediante un POST a https://parabank.parasoft.com/parabank/services/bank/withdraw La respuesta esperada debe tener código 200 y un cuerpo con mensaje de éxito.

# Próximas Mejores Prácticas:
- Implementar fixtures o generación dinámica de datos para evitar colisiones.
- Centralizar manejo de usuarios únicos.
- Automatizar verificación de saldos tras retiro o transferencia.


# Requisitos
- Node.js v. 18
- Visual Studio Code (recomendado)

# Instalación
- Clonar repositorio:

```bash
git clone https://github.com/Keyla-Narvaez/PRUEBAS-RETO-BCO-e2e.git
cd parabank-cypress-e2e

