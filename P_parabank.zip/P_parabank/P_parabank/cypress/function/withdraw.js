Cypress.Commands.add('withdraw', (aco,amon) => {
  cy.get('#accountTable a')
    .first()
    .invoke('attr', 'href')
    .then(href => {
      
      const accountId = aco;
      const amount = amon;
 
      cy.log(`Intentando retirar $${amount} de la cuenta ${accountId}`);
 
      if (!accountId || !amount) {
        throw new Error('accountId o amount no definidos');
      }
 
      const opts = {
        method: 'POST',
        url: 'https://parabank.parasoft.com/parabank/services/bank/withdraw',
        qs: { accountId, amount },
        headers: {
          'Content-Type': 'application/xml'
        },
        failOnStatusCode: false
      };
 
      cy.request(opts).then(response => {
        cy.log(`Código de respuesta: ${response.status}`);
        cy.log(`Respuesta: ${response.body}`);
 
        //debugging
        if (response.status !== 200) {
          throw new Error(`Retiro falló: ${response.status}`);
        }
 
        expect(response.status).to.eq(200);
      });
    });
});
