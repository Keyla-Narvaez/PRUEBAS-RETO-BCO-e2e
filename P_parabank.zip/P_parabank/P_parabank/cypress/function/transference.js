// cypress/support/commands.js

Cypress.Commands.add('transfer', (amount, fromAccountId, toAccountId) => {
  //formulario de transferencia
  cy.visit(
    `https://parabank.parasoft.com/parabank/transfer.htm?fromAccountId=${fromAccountId}`
  );
  //ingresar monto
  cy.get('input[id="amount"]').clear().type(amount);

 //select de destino esté visible
  cy.get('#toAccountId').should('be.visible');

  //opción con el value deseado exista
  cy.get('#toAccountId option')
    .should('contain.text', toAccountId.toString());

  //cuenta destino por su value exacto
  cy.get('#toAccountId').select(toAccountId.toString());


  // enviar
  //cy.get('input[type="submit"]').click();
  cy.get('input[value="Transfer"]').click();

  //verificar
  cy.contains('Transfer Complete!').should('be.visible');
});
