Cypress.Commands.add('login', (username, password) => {
  //pagina principal login
  cy.visit('https://parabank.parasoft.com/parabank/index.htm');

  //rellenar usuario y contraseña
  cy.get('input[name="username"]').clear().type(username);
  cy.get('input[name="password"]').clear().type(password, { log: false });

  //clic Login
  cy.get('input[value="Log In"]').click();

  //login exitoso
  cy.get('#leftPanel').should('contain', 'Accounts Overview');
});
