Cypress.Commands.add('logout', () => {
  //clic enlace de Logout
  cy.get('a[href="logout.htm"]').click();
  
  // volver al formulario de login
  cy.url().should('include', '/index.htm');
  
  // comprueba que el campo de usuario esté visible
  cy.get('input[name="username"]').should('be.visible');
});