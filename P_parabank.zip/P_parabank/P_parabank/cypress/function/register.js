
Cypress.Commands.add('register', (valor) => {
    cy.visit('https://parabank.parasoft.com/parabank/register.htm');

    // Llenar formulario
    cy.get('input[name="customer.firstName"]').type('Keylita');
    cy.get('input[name="customer.lastName"]').type('Nerez');
    cy.get('input[name="customer.address.street"]').type('Calle 1998');
    cy.get('input[name="customer.address.city"]').type('Ecuador');
    cy.get('input[name="customer.address.state"]').type('Guayaquil');
    cy.get('input[name="customer.address.zipCode"]').type('119922');
    cy.get('input[name="customer.phoneNumber"]').type('3044567');
    cy.get('input[name="customer.ssn"]').type('123-45-6009');

    // Credenciales para crear cuenta
    
    //valor = valor + 1; 

    cy.get('input[name="customer.username"]').type('keylita45');
    cy.get('input[name="customer.password"]').type('Pass10!');
    cy.get('input[name="repeatedPassword"]').type('Pass10!');

    // Enviar formulario
    cy.get('input[value="Register"]').click();

    // Verificar que fue exitoso
    cy.contains('Your account was created successfully. You are now logged in.').should('be.visible');

    })
