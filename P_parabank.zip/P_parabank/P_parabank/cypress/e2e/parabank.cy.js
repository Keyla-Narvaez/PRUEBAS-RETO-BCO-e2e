import '../function/register'
import '../function/login'
import '../function/logout'
import '../function/withdraw'
import '../function/transference'

describe('Prueba de Parabank', () => {
   it('Ingresar a la página y realizar registro', () => {
      // Visitar la página
      cy.register();
      //logout
      cy.logout();
      //login
      cy.login('keylita123','Pass10!');
      //withdraw
      cy.withdraw(25776,20);
      //transference
      cy.transfer('2','25110', '25776');
     
    });
  });