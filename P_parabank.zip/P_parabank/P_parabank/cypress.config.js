module.exports = {
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    env: {
    withdrawAmount: 50    // monto por defecto para el withdraw
  }
  },
};
